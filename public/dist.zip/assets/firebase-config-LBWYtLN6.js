import { getApp, getApps, initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { createUserWithEmailAndPassword, getAuth, onAuthStateChanged, reload, sendEmailVerification, signInAnonymously, signInWithEmailAndPassword, signOut, updateProfile } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { collection, deleteDoc, doc, getFirestore, onSnapshot, orderBy, query, serverTimestamp, setDoc } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { deleteObject, getDownloadURL, getStorage, ref, uploadBytesResumable } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-storage.js";
//#region \0vite/modulepreload-polyfill.js
(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
})();
//#endregion
//#region firebase-config.js
var defaultFirebaseConfig = {
	apiKey: "AIzaSyDemo-ProjectTrack-KeyForTesting",
	authDomain: "projecttrack-demo.firebaseapp.com",
	projectId: "projecttrack-demo",
	storageBucket: "projecttrack-demo.appspot.com",
	messagingSenderId: "123456789012",
	appId: "1:123456789012:web:abcdef123456"
};
var storedConfig = null;
try {
	const raw = localStorage.getItem("firebase_config");
	if (raw) storedConfig = JSON.parse(raw);
} catch (e) {}
var firebaseConfig = window.__FIREBASE_CONFIG__ || storedConfig || defaultFirebaseConfig;
var app = null;
var auth = null;
var db = null;
var storage = null;
var isRealFirebase = false;
var isConfigured = firebaseConfig && firebaseConfig.apiKey && !firebaseConfig.apiKey.includes("Demo-") && firebaseConfig.projectId !== "projecttrack-demo";
try {
	if (getApps().length === 0) app = initializeApp(firebaseConfig);
	else app = getApp();
	auth = getAuth(app);
	db = getFirestore(app);
	storage = getStorage(app);
	isRealFirebase = isConfigured;
	console.log("[Firebase] Initialized with config for project:", firebaseConfig.projectId);
} catch (err) {
	console.warn("[Firebase] SDK initialization note:", err.message);
}
//#endregion
export { updateProfile as C, storage as S, serverTimestamp as _, deleteDoc as a, signInWithEmailAndPassword as b, getDownloadURL as c, onSnapshot as d, orderBy as f, sendEmailVerification as g, reload as h, db as i, isRealFirebase as l, ref as m, collection as n, deleteObject as o, query as p, createUserWithEmailAndPassword as r, doc as s, auth as t, onAuthStateChanged as u, setDoc as v, uploadBytesResumable as w, signOut as x, signInAnonymously as y };
